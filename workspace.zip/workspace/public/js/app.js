const state = {
  user: null,
  stats: null,
  conversations: [],
  projects: [],
  currentConversationId: null,
  currentProjectId: null,
  generating: false,
  abortController: null,
};

const el = (id) => document.getElementById(id);

function formatCredits(n) {
  return Number(n || 0).toLocaleString("pt-BR");
}

function formatDate(value) {
  if (!value) return "—";
  return new Date(value).toLocaleString("pt-BR", {
    dateStyle: "short",
    timeStyle: "short",
  });
}

function escapeHtml(text) {
  return String(text)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function renderMarkdownLite(text) {
  const escaped = escapeHtml(text);
  const withCode = escaped.replace(/```([\s\S]*?)```/g, (_, code) => `<pre><code>${code}</code></pre>`);
  const withInline = withCode.replace(/`([^`]+)`/g, "<code>$1</code>");
  return withInline.replace(/\n/g, "<br>");
}

function toast(message, type = "") {
  const wrap = el("toasts");
  const node = document.createElement("div");
  node.className = `toast ${type}`;
  node.textContent = message;
  wrap.appendChild(node);
  setTimeout(() => node.remove(), 4200);
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    credentials: "same-origin",
    headers: {
      Accept: "application/json",
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...(options.headers || {}),
    },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (res.status === 401) {
    window.location.href = "/login";
    throw new Error("Não autenticado.");
  }
  if (!res.ok) {
    const err = new Error(data.error || "Erro inesperado.");
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

function setCredits(value) {
  if (state.user) state.user.credits = value;
  el("credits-chip").textContent = `${formatCredits(value)} créditos`;
  el("dash-credits").textContent = formatCredits(value);
  el("credits-page-balance").textContent = formatCredits(value);
  el("set-credits").value = formatCredits(value);
}

function showView(name) {
  document.querySelectorAll(".view, .chat-view").forEach((node) => node.classList.remove("active"));
  const target = el(`view-${name}`);
  if (target) target.classList.add("active");
  document.querySelectorAll(".nav-item").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.view === name);
  });
  el("sidebar").classList.remove("open");
  if (name === "dashboard") el("top-title").textContent = `Olá, ${state.user?.name || ""}`;
  if (name === "history") el("top-title").textContent = "Histórico";
  if (name === "projects") el("top-title").textContent = "Projetos";
  if (name === "credits") el("top-title").textContent = "Créditos";
  if (name === "invite") el("top-title").textContent = "Indicar e ganhar";
  if (name === "settings") el("top-title").textContent = "Configurações";
  if (name === "chat") el("top-title").textContent = "Chat";
}

function renderHistoryLists() {
  const side = el("sidebar-history");
  const page = el("history-page");
  if (!state.conversations.length) {
    side.innerHTML = `<p style="color:var(--faint);font-size:0.82rem;padding:8px">Nenhuma conversa ainda.</p>`;
    page.innerHTML = `<p style="color:var(--muted)">Você ainda não possui conversas.</p>`;
    return;
  }

  side.innerHTML = state.conversations
    .slice(0, 12)
    .map(
      (c) => `<div class="hist-item ${c.id === state.currentConversationId ? "active" : ""}" data-id="${c.id}">
        <span class="title">${escapeHtml(c.title)}</span>
        <button class="icon" data-del="${c.id}" type="button" aria-label="Excluir">✕</button>
      </div>`
    )
    .join("");

  page.innerHTML = state.conversations
    .map(
      (c) => `<article class="card" style="margin-bottom:10px;display:flex;justify-content:space-between;gap:12px;align-items:center">
        <div>
          <h3>${escapeHtml(c.title)}</h3>
          <p>${formatDate(c.updated_at)}</p>
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-primary" data-open="${c.id}" type="button">Abrir</button>
          <button class="btn btn-danger" data-del="${c.id}" type="button">Excluir</button>
        </div>
      </article>`
    )
    .join("");
}

function renderProjects() {
  const grid = el("projects-grid");
  if (!state.projects.length) {
    grid.innerHTML = `<p style="color:var(--muted)">Nenhum projeto criado.</p>`;
    return;
  }
  grid.innerHTML = state.projects
    .map(
      (p) => `<article class="card">
        <h3>${escapeHtml(p.name)}</h3>
        <p>${escapeHtml(p.description || "Sem descrição")}</p>
        <p style="margin-top:8px;font-size:0.82rem">${formatDate(p.created_at)}</p>
        <div style="display:flex;gap:8px;margin-top:12px">
          <button class="btn btn-primary" data-chat-project="${p.id}" type="button">Novo chat</button>
          <button class="btn btn-ghost" data-open-project="${p.id}" type="button">Abrir</button>
          <button class="btn btn-danger" data-del-project="${p.id}" type="button">Excluir</button>
        </div>
      </article>`
    )
    .join("");
}

function addMessage(role, content, { streaming = false } = {}) {
  el("empty-chat")?.remove();
  const wrap = document.createElement("div");
  wrap.className = "msg";
  wrap.innerHTML = `
    <div class="avatar ${role === "assistant" ? "nova" : ""}">${role === "assistant" ? "N" : "U"}</div>
    <div class="bubble ${role === "user" ? "user" : ""}">${
      streaming
        ? `<span class="typing"><i></i><i></i><i></i></span>`
        : renderMarkdownLite(content)
    }</div>`;
  el("messages").appendChild(wrap);
  el("messages").scrollTop = el("messages").scrollHeight;
  return wrap.querySelector(".bubble");
}

async function loadConversation(id) {
  const data = await api(`/api/conversations/${id}`);
  state.currentConversationId = id;
  showView("chat");
  const box = el("messages");
  box.innerHTML = "";
  if (!data.messages.length) {
    box.innerHTML = `<div class="empty-chat" id="empty-chat">
      <h2>Continue esta conversa</h2>
      <p>Envie uma nova mensagem para a NOVA AI.</p>
    </div>`;
  } else {
    data.messages.forEach((m) => addMessage(m.role, m.content));
  }
  renderHistoryLists();
}

async function startNewChat(projectId = null) {
  state.currentConversationId = null;
  state.currentProjectId = projectId || null;
  showView("chat");
  el("messages").innerHTML = `<div class="empty-chat" id="empty-chat">
    <div class="logo-mark" style="margin:0 auto"><svg viewBox="0 0 24 24" fill="none"><path d="M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3z" stroke="#081018" stroke-width="1.6"/><circle cx="12" cy="12" r="2.2" fill="#081018"/></svg></div>
    <h2>Como posso ajudar?</h2>
    <p>Envie uma mensagem para começar uma conversa com a NOVA AI.</p>
  </div>`;
  el("composer-input").focus();
}

function setGenerating(on) {
  state.generating = on;
  el("send-btn").style.display = on ? "none" : "grid";
  el("stop-btn").style.display = on ? "grid" : "none";
  el("composer-input").disabled = on;
}

async function sendMessage(text) {
  if (!text || state.generating) return;
  addMessage("user", text);
  const pending = addMessage("assistant", "", { streaming: true });
  setGenerating(true);
  state.abortController = new AbortController();

  try {
    const data = await api("/api/chat", {
      method: "POST",
      body: JSON.stringify({
        message: text,
        conversationId: state.currentConversationId,
        projectId: state.currentConversationId ? undefined : state.currentProjectId,
      }),
      signal: state.abortController.signal,
    });
    pending.innerHTML = renderMarkdownLite(data.message.content);
    state.currentConversationId = data.conversationId;
    setCredits(data.credits);
    await refreshConversations();
  } catch (err) {
    if (err.data && err.data.conversationId) {
      state.currentConversationId = err.data.conversationId;
      await refreshConversations();
    }
    if (err.name === "AbortError") {
      pending.innerHTML = "Geração interrompida.";
    } else if (err.status === 402) {
      pending.innerHTML = escapeHtml(
        err.message || "Seus créditos acabaram. Aguarde o próximo ciclo para receber novos créditos."
      );
      toast(err.message, "error");
    } else {
      pending.innerHTML = escapeHtml(err.message || "Não foi possível obter resposta da IA.");
      toast(err.message || "Erro ao falar com a IA.", "error");
    }
  } finally {
    setGenerating(false);
    el("messages").scrollTop = el("messages").scrollHeight;
  }
}

async function refreshConversations() {
  const data = await api("/api/conversations");
  state.conversations = data.conversations || [];
  renderHistoryLists();
}

async function refreshProjects() {
  const data = await api("/api/projects");
  state.projects = data.projects || [];
  renderProjects();
}

async function refreshCreditsPage() {
  const data = await api("/api/credit-transactions");
  setCredits(data.credits);
  const body = el("tx-body");
  if (!data.transactions.length) {
    body.innerHTML = `<tr><td colspan="4">Nenhuma transação ainda.</td></tr>`;
    return;
  }
  body.innerHTML = data.transactions
    .map((t) => {
      const amount = Number(t.amount);
      return `<tr>
        <td>${formatDate(t.created_at)}</td>
        <td>${escapeHtml(t.type)}</td>
        <td>${escapeHtml(t.description)}</td>
        <td class="${amount < 0 ? "neg" : "pos"}">${amount > 0 ? "+" : ""}${formatCredits(amount)}</td>
      </tr>`;
    })
    .join("");
}

async function refreshInvite() {
  const data = await api("/api/referrals");
  const link = `${window.location.origin}/r/${data.code}`;
  el("invite-link").value = link;
  el("invite-code").textContent = data.code;
  el("invite-count").textContent = data.inviteCount;
  el("invite-earned").textContent = formatCredits(data.totalEarned);
  el("invite-reward").textContent = formatCredits(data.reward);
  const body = el("invite-body");
  if (!data.invitations.length) {
    body.innerHTML = `<tr><td colspan="3">Nenhum convite concluído ainda. Compartilhe seu link.</td></tr>`;
    return;
  }
  body.innerHTML = data.invitations
    .map(
      (row) => `<tr>
        <td>${escapeHtml(row.name)}</td>
        <td>${formatDate(row.createdAt)}</td>
        <td class="pos">+${formatCredits(row.rewardCredits)}</td>
      </tr>`
    )
    .join("");
}

async function copyInviteLink() {
  const value = el("invite-link").value;
  if (!value) return;
  try {
    await navigator.clipboard.writeText(value);
    toast("Link de convite copiado.", "ok");
  } catch {
    el("invite-link").select();
    document.execCommand("copy");
    toast("Link de convite copiado.", "ok");
  }
}

async function logout() {
  await api("/api/auth/logout", { method: "POST" });
  window.location.href = "/";
}

async function init() {
  try {
    const me = await api("/api/me");
    state.user = me.user;
    state.stats = me.stats;
    el("dash-hello").textContent = `Olá, ${me.user.name}`;
    el("top-title").textContent = `Olá, ${me.user.name}`;
    el("stat-chats").textContent = me.stats.conversations;
    el("stat-projects").textContent = me.stats.projects;
    el("stat-messages").textContent = me.stats.messages;
    el("set-name").value = me.user.name;
    el("set-email").value = me.user.email;
    el("set-created").value = formatDate(me.user.createdAt);
    setCredits(me.user.credits);
    await Promise.all([refreshConversations(), refreshProjects(), refreshCreditsPage(), refreshInvite()]);
    const recent = (await api("/api/credit-transactions")).transactions.slice(0, 4);
    el("recent-usage").innerHTML = recent.length
      ? recent.map((t) => `<p>${escapeHtml(t.description)} · ${formatDate(t.created_at)}</p>`).join("")
      : "Nenhum uso recente.";
  } catch (err) {
    toast(err.message || "Falha ao carregar a conta.", "error");
  }
}

document.querySelectorAll(".nav-item").forEach((btn) => {
  btn.addEventListener("click", async () => {
    const view = btn.dataset.view;
    showView(view);
    if (view === "history") await refreshConversations();
    if (view === "projects") await refreshProjects();
    if (view === "credits") await refreshCreditsPage();
    if (view === "invite") await refreshInvite();
  });
});

el("new-chat-btn").addEventListener("click", startNewChat);
el("dash-new-chat").addEventListener("click", startNewChat);
el("dash-invite-btn").addEventListener("click", async () => {
  showView("invite");
  await refreshInvite();
});
el("copy-invite").addEventListener("click", copyInviteLink);
el("logout-btn").addEventListener("click", logout);
el("settings-logout").addEventListener("click", logout);
el("menu-btn").addEventListener("click", () => el("sidebar").classList.toggle("open"));

el("composer").addEventListener("submit", (e) => {
  e.preventDefault();
  const input = el("composer-input");
  const text = input.value.trim();
  input.value = "";
  input.style.height = "auto";
  sendMessage(text);
});

el("composer-input").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    el("composer").requestSubmit();
  }
});

el("composer-input").addEventListener("input", () => {
  const input = el("composer-input");
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 180) + "px";
});

el("stop-btn").addEventListener("click", () => {
  if (state.abortController) state.abortController.abort();
});

el("sidebar-history").addEventListener("click", async (e) => {
  const del = e.target.closest("[data-del]");
  const item = e.target.closest("[data-id]");
  if (del) {
    e.stopPropagation();
    await api(`/api/conversations/${del.dataset.del}`, { method: "DELETE" });
    if (state.currentConversationId === del.dataset.del) startNewChat();
    await refreshConversations();
    toast("Conversa excluída.", "ok");
    return;
  }
  if (item) await loadConversation(item.dataset.id);
});

el("history-page").addEventListener("click", async (e) => {
  const open = e.target.closest("[data-open]");
  const del = e.target.closest("[data-del]");
  if (open) await loadConversation(open.dataset.open);
  if (del) {
    await api(`/api/conversations/${del.dataset.del}`, { method: "DELETE" });
    await refreshConversations();
    toast("Conversa excluída.", "ok");
  }
});

el("new-project-btn").addEventListener("click", () => el("project-modal").classList.add("show"));
el("project-cancel").addEventListener("click", () => el("project-modal").classList.remove("show"));

el("project-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  try {
    await api("/api/projects", {
      method: "POST",
      body: JSON.stringify({
        name: el("project-name").value,
        description: el("project-desc").value,
      }),
    });
    el("project-modal").classList.remove("show");
    el("project-form").reset();
    await refreshProjects();
    toast("Projeto criado.", "ok");
  } catch (err) {
    toast(err.message, "error");
  }
});

el("projects-grid").addEventListener("click", async (e) => {
  const del = e.target.closest("[data-del-project]");
  const open = e.target.closest("[data-open-project]");
  const chat = e.target.closest("[data-chat-project]");
  if (chat) {
    startNewChat(chat.dataset.chatProject);
    return;
  }
  if (del) {
    await api(`/api/projects/${del.dataset.delProject}`, { method: "DELETE" });
    await refreshProjects();
    toast("Projeto excluído.", "ok");
  }
  if (open) {
    const data = await api(`/api/projects/${open.dataset.openProject}`);
    showView("history");
    const page = el("history-page");
    if (!data.conversations.length) {
      page.innerHTML = `<p style="color:var(--muted)">Este projeto ainda não tem conversas.</p>`;
      return;
    }
    page.innerHTML = `<h3 style="margin-bottom:12px">${escapeHtml(data.project.name)}</h3>` +
      data.conversations
        .map(
          (c) => `<article class="card" style="margin-bottom:10px;display:flex;justify-content:space-between;gap:12px;align-items:center">
            <div><h3>${escapeHtml(c.title)}</h3><p>${formatDate(c.updated_at)}</p></div>
            <button class="btn btn-primary" data-open="${c.id}" type="button">Abrir</button>
          </article>`
        )
        .join("");
  }
});

el("settings-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  el("settings-error").textContent = "";
  try {
    const data = await api("/api/me", {
      method: "PATCH",
      body: JSON.stringify({ name: el("set-name").value }),
    });
    state.user = data.user;
    el("dash-hello").textContent = `Olá, ${data.user.name}`;
    toast("Nome atualizado.", "ok");
  } catch (err) {
    el("settings-error").textContent = err.message;
  }
});

init();
