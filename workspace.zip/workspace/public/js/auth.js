const params = new URLSearchParams(window.location.search);
const authError = params.get("error");
if (authError) {
  const box = document.getElementById("error");
  if (box) {
    box.textContent =
      authError === "github_not_configured"
        ? "O login com GitHub ainda não foi configurado no servidor."
        : "Não foi possível entrar com o GitHub. Tente novamente.";
  }
}

async function submitAuth(url, body, errorEl) {
  errorEl.textContent = "";
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      credentials: "same-origin",
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
      errorEl.textContent = data.error || "Não foi possível continuar.";
      return;
    }
    window.location.href = "/app";
  } catch {
    errorEl.textContent = "Falha de conexão. Tente novamente.";
  }
}

const loginForm = document.getElementById("login-form");
if (loginForm) {
  loginForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const btn = loginForm.querySelector("button[type=submit]");
    btn.disabled = true;
    submitAuth(
      "/api/auth/login",
      {
        email: loginForm.email.value,
        password: loginForm.password.value,
      },
      document.getElementById("error")
    ).finally(() => {
      btn.disabled = false;
    });
  });
}

function referralCodeFromUrl() {
  const params = new URLSearchParams(window.location.search);
  return (params.get("ref") || "").trim().toUpperCase();
}

async function showReferralBanner() {
  const banner = document.getElementById("ref-banner");
  const code = referralCodeFromUrl();
  if (!banner || !code) return;
  try {
    const res = await fetch(`/api/referrals/preview/${encodeURIComponent(code)}`);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return;
    banner.style.display = "block";
    banner.textContent = `${data.name} te convidou. Crie sua conta e vocês avançam juntos na NOVA AI.`;
  } catch {
    /* ignore */
  }
}

const registerForm = document.getElementById("register-form");
if (registerForm) {
  showReferralBanner();
  registerForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const btn = registerForm.querySelector("button[type=submit]");
    btn.disabled = true;
    submitAuth(
      "/api/auth/register",
      {
        name: registerForm.name.value,
        email: registerForm.email.value,
        password: registerForm.password.value,
        referralCode: referralCodeFromUrl(),
      },
      document.getElementById("error")
    ).finally(() => {
      btn.disabled = false;
    });
  });
}
