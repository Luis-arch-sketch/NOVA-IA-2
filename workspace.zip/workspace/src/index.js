require("dotenv").config();

const path = require("path");
const express = require("express");
const helmet = require("helmet");
const cookieParser = require("cookie-parser");
const rateLimit = require("express-rate-limit");

const { pool } = require("./db/pool");
const { migrate } = require("./db/migrate");
const { sessionMiddleware } = require("./middleware/session");
const { requireAuth, optionalAuth } = require("./middleware/auth");
const { errorHandler } = require("./middleware/errorHandler");
const { grantDailyCreditsIfNeeded } = require("./services/credits");

const authRoutes = require("./routes/auth");
const { githubAuthRouter } = require("./routes/github");
const meRoutes = require("./routes/me");
const chatRoutes = require("./routes/chat");
const conversationRoutes = require("./routes/conversations");
const projectRoutes = require("./routes/projects");
const creditRoutes = require("./routes/credits");
const referralRoutes = require("./routes/referrals");
const { backfillReferralCodes, sanitizeReferralCode } = require("./services/referrals");

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || "0.0.0.0";

async function bootstrap() {
  await migrate();
  await backfillReferralCodes();

  const app = express();

  app.set("trust proxy", 1);

  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
          fontSrc: ["'self'", "https://fonts.gstatic.com", "data:"],
          imgSrc: ["'self'", "data:", "https://avatars.githubusercontent.com"],
          connectSrc: ["'self'"],
          objectSrc: ["'none'"],
          frameAncestors: ["'self'", "https:", "http:"],
        },
      },
      crossOriginEmbedderPolicy: false,
      crossOriginOpenerPolicy: false,
      frameguard: false,
    })
  );

  app.use(express.json({ limit: "1mb" }));
  app.use(express.urlencoded({ extended: false }));
  app.use(cookieParser());
  app.use(sessionMiddleware);

  const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 40,
    standardHeaders: true,
    legacyHeaders: false,
    message: { error: "Muitas tentativas. Aguarde alguns minutos." },
  });

  const apiLimiter = rateLimit({
    windowMs: 60 * 1000,
    max: 120,
    standardHeaders: true,
    legacyHeaders: false,
  });

  app.use("/api/auth", authLimiter, authRoutes);
  app.use("/api/auth", githubAuthRouter);
  app.use("/api", apiLimiter);

  app.use("/api/me", requireAuth, meRoutes);
  app.use("/api/chat", requireAuth, chatRoutes);
  app.use("/api/conversations", requireAuth, conversationRoutes);
  app.use("/api/projects", requireAuth, projectRoutes);
  app.get("/api/referrals/preview/:code", async (req, res, next) => {
    try {
      const { findReferrerByCode } = require("./services/referrals");
      const referrer = await findReferrerByCode(req.params.code);
      if (!referrer) {
        return res.status(404).json({ error: "Código de indicação inválido." });
      }
      res.json({ valid: true, name: referrer.name, code: referrer.referral_code });
    } catch (err) {
      next(err);
    }
  });

  app.use("/api/credits", requireAuth, creditRoutes);
  app.use("/api/credit-transactions", requireAuth, creditRoutes);
  app.use("/api/referrals", requireAuth, referralRoutes);

  app.get("/api/health", async (_req, res) => {
    try {
      await pool.query("SELECT 1");
      res.json({ ok: true, service: "nova-ai" });
    } catch {
      res.status(503).json({ ok: false });
    }
  });

  app.use(express.static(path.join(__dirname, "..", "public"), { index: false }));

  const sendPage = (file) => (_req, res) => {
    res.sendFile(path.join(__dirname, "..", "public", file));
  };

  app.get("/", optionalAuth, (req, res) => {
    if (req.user) return res.redirect("/app");
    res.sendFile(path.join(__dirname, "..", "public", "index.html"));
  });

  app.get("/login", optionalAuth, (req, res) => {
    if (req.user) return res.redirect("/app");
    res.sendFile(path.join(__dirname, "..", "public", "login.html"));
  });

  app.get("/register", optionalAuth, (req, res) => {
    if (req.user) return res.redirect("/app");
    const ref = sanitizeReferralCode(req.query.ref || "");
    if (ref) {
      res.cookie("nova_ref", ref, {
        httpOnly: true,
        sameSite: "lax",
        maxAge: 30 * 24 * 60 * 60 * 1000,
        secure: process.env.NODE_ENV === "production",
      });
    }
    res.sendFile(path.join(__dirname, "..", "public", "register.html"));
  });

  app.get("/r/:code", (req, res) => {
    const ref = sanitizeReferralCode(req.params.code);
    if (ref) {
      res.cookie("nova_ref", ref, {
        httpOnly: true,
        sameSite: "lax",
        maxAge: 30 * 24 * 60 * 60 * 1000,
        secure: process.env.NODE_ENV === "production",
      });
    }
    res.redirect(`/register?ref=${encodeURIComponent(ref)}`);
  });

  app.get("/app", requireAuth, async (req, res, next) => {
    try {
      await grantDailyCreditsIfNeeded(req.user.id);
      res.sendFile(path.join(__dirname, "..", "public", "app.html"));
    } catch (err) {
      next(err);
    }
  });

  app.get("/app/*", requireAuth, sendPage("app.html"));

  app.use(errorHandler);

  app.listen(PORT, HOST, () => {
    console.log(`NOVA AI listening on http://${HOST}:${PORT}`);
  });
}

bootstrap().catch((err) => {
  console.error("Failed to start NOVA AI:", err);
  process.exit(1);
});
