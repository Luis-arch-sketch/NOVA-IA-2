const { pool } = require("../db/pool");
const { grantDailyCreditsIfNeeded } = require("../services/credits");

function publicUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    credits: Number(row.credits),
    referralCode: row.referral_code || null,
    githubLogin: row.github_login || null,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

async function loadUser(userId) {
  const { rows } = await pool.query(
    "SELECT id, name, email, credits, referral_code, github_login, created_at, updated_at FROM users WHERE id = $1",
    [userId]
  );
  return rows[0] || null;
}

async function requireAuth(req, res, next) {
  try {
    const wantsJson =
      (req.originalUrl || req.path || "").startsWith("/api") ||
      (req.headers.accept || "").includes("application/json");

    if (!req.session || !req.session.userId) {
      if (wantsJson) {
        return res.status(401).json({ error: "Não autenticado." });
      }
      return res.redirect("/login");
    }

    const user = await loadUser(req.session.userId);
    if (!user) {
      req.session.destroy(() => {});
      if (wantsJson) {
        return res.status(401).json({ error: "Sessão inválida." });
      }
      return res.redirect("/login");
    }

    const credits = await grantDailyCreditsIfNeeded(user.id);
    user.credits = credits;
    req.user = publicUser(user);
    next();
  } catch (err) {
    next(err);
  }
}

async function optionalAuth(req, _res, next) {
  try {
    if (req.session && req.session.userId) {
      const user = await loadUser(req.session.userId);
      if (user) req.user = publicUser(user);
    }
    next();
  } catch (err) {
    next(err);
  }
}

module.exports = { requireAuth, optionalAuth, publicUser, loadUser };
