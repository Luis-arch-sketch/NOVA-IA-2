function errorHandler(err, req, res, _next) {
  console.error(err);

  if (res.headersSent) return;

  const status = err.status || 500;
  const isApi = req.path.startsWith("/api") || req.headers.accept?.includes("application/json");

  if (isApi) {
    return res.status(status).json({
      error: status === 500 ? "Erro interno do servidor." : err.message,
    });
  }

  res.status(status).send(status === 500 ? "Erro interno do servidor." : err.message);
}

module.exports = { errorHandler };
