const express = require("express");
const bcrypt = require("bcrypt");
const { pool } = require("../db/pool");
const { publicUser } = require("../middleware/auth");
const {
  sanitizeString,
  isValidEmail,
  isValidPassword,
  isValidName,
} = require("../utils/validation");
const { INITIAL_CREDITS } = require("../services/credits");
const {
  generateReferralCode,
  findReferrerByCode,
  applyReferralReward,
  sanitizeReferralCode,
} = require("../services/referrals");

const router = express.Router();
const SALT_ROUNDS = 12;

async function createUniqueCode(client) {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const code = generateReferralCode();
    const exists = await client.query(
      "SELECT id FROM users WHERE referral_code = $1",
      [code]
    );
    if (!exists.rows.length) return code;
  }
  throw new Error("Não foi possível gerar um código de indicação.");
}

router.post("/register", async (req, res, next) => {
  try {
    const name = sanitizeString(req.body.name, 80);
    const email = sanitizeString(req.body.email, 160).toLowerCase();
    const password = typeof req.body.password === "string" ? req.body.password : "";

    if (!isValidName(name)) {
      return res.status(400).json({ error: "Informe um nome válido (2 a 80 caracteres)." });
    }
    if (!isValidEmail(email)) {
      return res.status(400).json({ error: "Informe um e-mail válido." });
    }
    if (!isValidPassword(password)) {
      return res.status(400).json({ error: "A senha deve ter entre 8 e 128 caracteres." });
    }

    const existing = await pool.query("SELECT id FROM users WHERE email = $1", [email]);
    if (existing.rows.length) {
      return res.status(409).json({ error: "Este e-mail já está em uso." });
    }

    const incomingCode = sanitizeReferralCode(
      req.body.referralCode || req.body.ref || req.cookies?.nova_ref || ""
    );
    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
    const client = await pool.connect();
    try {
      await client.query("BEGIN");

      let referrer = null;
      if (incomingCode) {
        referrer = await findReferrerByCode(incomingCode, client);
      }

      const ownCode = await createUniqueCode(client);
      const { rows } = await client.query(
        `INSERT INTO users (name, email, password_hash, credits, last_credit_grant_at, referral_code, referred_by_user_id)
         VALUES ($1, $2, $3, $4, NOW(), $5, $6)
         RETURNING id, name, email, credits, referral_code, created_at, updated_at`,
        [
          name,
          email,
          passwordHash,
          INITIAL_CREDITS.toString(),
          ownCode,
          referrer ? referrer.id : null,
        ]
      );

      await client.query(
        `INSERT INTO credit_transactions (user_id, amount, type, description)
         VALUES ($1, $2, 'grant', $3)`,
        [rows[0].id, INITIAL_CREDITS.toString(), "Créditos iniciais ao criar a conta."]
      );

      if (referrer && referrer.id !== rows[0].id) {
        await applyReferralReward({
          client,
          referrerId: referrer.id,
          referredId: rows[0].id,
        });
      }

      await client.query("COMMIT");

      req.session.userId = rows[0].id;
      res.clearCookie("nova_ref");
      req.session.save((err) => {
        if (err) return next(err);
        res.status(201).json({ user: publicUser(rows[0]) });
      });
    } catch (err) {
      await client.query("ROLLBACK");
      throw err;
    } finally {
      client.release();
    }
  } catch (err) {
    next(err);
  }
});

router.post("/login", async (req, res, next) => {
  try {
    const email = sanitizeString(req.body.email, 160).toLowerCase();
    const password = typeof req.body.password === "string" ? req.body.password : "";

    if (!isValidEmail(email) || !password) {
      return res.status(400).json({ error: "E-mail ou senha inválidos." });
    }

    const { rows } = await pool.query(
      "SELECT id, name, email, password_hash, credits, referral_code, github_login, created_at, updated_at FROM users WHERE email = $1",
      [email]
    );
    const user = rows[0];
    if (!user) {
      return res.status(401).json({ error: "E-mail ou senha incorretos." });
    }

    if (!user.password_hash) {
      return res.status(401).json({ error: "Esta conta entra pelo GitHub." });
    }
    const ok = await bcrypt.compare(password, user.password_hash);
    if (!ok) {
      return res.status(401).json({ error: "E-mail ou senha incorretos." });
    }

    req.session.userId = user.id;
    req.session.save((err) => {
      if (err) return next(err);
      res.json({ user: publicUser(user) });
    });
  } catch (err) {
    next(err);
  }
});

router.post("/logout", (req, res, next) => {
  if (!req.session) {
    return res.json({ ok: true });
  }
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie("nova.sid");
    res.json({ ok: true });
  });
});

module.exports = router;
