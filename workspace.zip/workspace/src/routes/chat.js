const express = require("express");
const { pool } = require("../db/pool");
const { sanitizeString } = require("../utils/validation");
const { generateReply } = require("../services/ai");
const {
  calculateCreditCost,
  deductCredits,
  assertHasCredits,
} = require("../services/credits");
const { listRepoFiles } = require("../services/github");

const router = express.Router();

function makeTitle(text) {
  const cleaned = text.replace(/\s+/g, " ").trim();
  if (cleaned.length <= 48) return cleaned || "Novo chat";
  return cleaned.slice(0, 45) + "...";
}

router.post("/", async (req, res, next) => {
  try {
    const content = sanitizeString(req.body.message || req.body.content, 8000);
    let conversationId = req.body.conversationId || null;
    let projectId = req.body.projectId || null;

    if (!content) {
      return res.status(400).json({ error: "Escreva uma mensagem." });
    }

    await assertHasCredits(req.user.id);

    let project = null;
    if (projectId) {
      const ownedProject = await pool.query(
        `SELECT id, name, description, source, github_full_name, github_html_url, github_default_branch
         FROM projects WHERE id = $1 AND user_id = $2`,
        [projectId, req.user.id]
      );
      if (!ownedProject.rows.length) {
        return res.status(404).json({ error: "Projeto não encontrado." });
      }
      project = ownedProject.rows[0];
    } else if (conversationId) {
      const linked = await pool.query(
        `SELECT p.id, p.name, p.description, p.source, p.github_full_name, p.github_html_url, p.github_default_branch
         FROM conversations c
         LEFT JOIN projects p ON p.id = c.project_id
         WHERE c.id = $1 AND c.user_id = $2`,
        [conversationId, req.user.id]
      );
      if (linked.rows[0]?.id) project = linked.rows[0];
    } else {
      projectId = null;
    }

    if (conversationId) {
      const owned = await pool.query(
        "SELECT id FROM conversations WHERE id = $1 AND user_id = $2",
        [conversationId, req.user.id]
      );
      if (!owned.rows.length) {
        return res.status(404).json({ error: "Conversa não encontrada." });
      }
    } else {
      const created = await pool.query(
        `INSERT INTO conversations (user_id, title, project_id)
         VALUES ($1, $2, $3)
         RETURNING id`,
        [req.user.id, makeTitle(content), projectId]
      );
      conversationId = created.rows[0].id;
    }

    await pool.query(
      `INSERT INTO messages (conversation_id, role, content)
       VALUES ($1, 'user', $2)`,
      [conversationId, content]
    );

    const history = await pool.query(
      `SELECT role, content FROM messages
       WHERE conversation_id = $1 AND role IN ('user', 'assistant')
       ORDER BY created_at ASC
       LIMIT 40`,
      [conversationId]
    );

    let extraSystem = "";
    if (project?.github_full_name) {
      extraSystem =
        `O usuário está editando o repositório GitHub ${project.github_full_name} ` +
        `(branch ${project.github_default_branch || "main"}) na NOVA AI. ` +
        "Trate este repositório como o projeto atual. Sugira mudanças concretas nos arquivos.";
      try {
        const tree = await listRepoFiles(req.user.id, project);
        extraSystem += `\nArquivos do repositório:\n${tree.files
          .slice(0, 80)
          .map((f) => `- ${f.path}`)
          .join("\n")}`;
      } catch {
        /* GitHub tree is optional context */
      }
    }

    let reply;
    try {
      reply = await generateReply(history.rows, extraSystem);
    } catch (aiErr) {
      if (aiErr.status === 503 || aiErr.message?.includes("OPENAI_API_KEY")) {
        return res.status(503).json({
          error: "A API da IA não está configurada. Defina OPENAI_API_KEY no servidor.",
          conversationId,
        });
      }
      const status = aiErr.status && aiErr.status < 500 ? aiErr.status : 502;
      return res.status(status).json({
        error: "Não foi possível obter resposta da IA. Tente novamente em instantes.",
        conversationId,
      });
    }

    const cost = calculateCreditCost(reply.usage);
    let remaining;
    try {
      remaining = await deductCredits({
        userId: req.user.id,
        cost,
        description: `Comando enviado à IA (−${cost.toLocaleString("pt-BR")} créditos)`,
        conversationId,
      });
    } catch (creditErr) {
      if (creditErr.code === "INSUFFICIENT_CREDITS") {
        return res.status(402).json({
          error: creditErr.message,
          conversationId,
        });
      }
      throw creditErr;
    }

    const saved = await pool.query(
      `INSERT INTO messages
         (conversation_id, role, content, prompt_tokens, completion_tokens, credit_cost)
       VALUES ($1, 'assistant', $2, $3, $4, $5)
       RETURNING id, role, content, credit_cost, created_at`,
      [
        conversationId,
        reply.content,
        reply.usage.prompt_tokens,
        reply.usage.completion_tokens,
        cost,
      ]
    );

    await pool.query(
      "UPDATE conversations SET updated_at = NOW() WHERE id = $1",
      [conversationId]
    );

    res.json({
      conversationId,
      message: saved.rows[0],
      usage: reply.usage,
      creditCost: cost,
      credits: remaining,
    });
  } catch (err) {
    if (err.code === "INSUFFICIENT_CREDITS") {
      return res.status(402).json({ error: err.message });
    }
    next(err);
  }
});

module.exports = router;
