const express = require("express");
const { pool } = require("../db/pool");
const { sanitizeString } = require("../utils/validation");

const router = express.Router();

router.get("/", async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, title, project_id, created_at, updated_at
       FROM conversations
       WHERE user_id = $1
       ORDER BY updated_at DESC
       LIMIT 100`,
      [req.user.id]
    );
    res.json({ conversations: rows });
  } catch (err) {
    next(err);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const title = sanitizeString(req.body.title || "Novo chat", 120) || "Novo chat";
    const projectId = req.body.projectId || null;

    if (projectId) {
      const owned = await pool.query(
        "SELECT id FROM projects WHERE id = $1 AND user_id = $2",
        [projectId, req.user.id]
      );
      if (!owned.rows.length) {
        return res.status(404).json({ error: "Projeto não encontrado." });
      }
    }

    const { rows } = await pool.query(
      `INSERT INTO conversations (user_id, title, project_id)
       VALUES ($1, $2, $3)
       RETURNING id, title, project_id, created_at, updated_at`,
      [req.user.id, title, projectId]
    );
    res.status(201).json({ conversation: rows[0] });
  } catch (err) {
    next(err);
  }
});

router.get("/:id", async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, title, project_id, created_at, updated_at
       FROM conversations WHERE id = $1 AND user_id = $2`,
      [req.params.id, req.user.id]
    );
    if (!rows.length) {
      return res.status(404).json({ error: "Conversa não encontrada." });
    }

    const messages = await pool.query(
      `SELECT id, role, content, credit_cost, created_at
       FROM messages
       WHERE conversation_id = $1
       ORDER BY created_at ASC`,
      [req.params.id]
    );

    res.json({ conversation: rows[0], messages: messages.rows });
  } catch (err) {
    next(err);
  }
});

router.patch("/:id", async (req, res, next) => {
  try {
    const title = sanitizeString(req.body.title, 120);
    if (!title) {
      return res.status(400).json({ error: "Informe um título." });
    }
    const { rows } = await pool.query(
      `UPDATE conversations SET title = $1, updated_at = NOW()
       WHERE id = $2 AND user_id = $3
       RETURNING id, title, project_id, created_at, updated_at`,
      [title, req.params.id, req.user.id]
    );
    if (!rows.length) {
      return res.status(404).json({ error: "Conversa não encontrada." });
    }
    res.json({ conversation: rows[0] });
  } catch (err) {
    next(err);
  }
});

router.delete("/:id", async (req, res, next) => {
  try {
    const result = await pool.query(
      "DELETE FROM conversations WHERE id = $1 AND user_id = $2",
      [req.params.id, req.user.id]
    );
    if (!result.rowCount) {
      return res.status(404).json({ error: "Conversa não encontrada." });
    }
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
