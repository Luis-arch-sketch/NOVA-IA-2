const express = require("express");
const { pool } = require("../db/pool");
const { getBalance, grantDailyCreditsIfNeeded } = require("../services/credits");

const router = express.Router();

async function listTransactions(req, res, next) {
  try {
    const { rows } = await pool.query(
      `SELECT id, amount, type, description, conversation_id, created_at
       FROM credit_transactions
       WHERE user_id = $1
       ORDER BY created_at DESC
       LIMIT 50`,
      [req.user.id]
    );
    const credits = await getBalance(req.user.id);
    res.json({ credits, transactions: rows });
  } catch (err) {
    next(err);
  }
}

router.get("/", async (req, res, next) => {
  try {
    if (req.baseUrl.includes("credit-transactions")) {
      return listTransactions(req, res, next);
    }
    const credits = await grantDailyCreditsIfNeeded(req.user.id);
    res.json({ credits, balance: credits });
  } catch (err) {
    next(err);
  }
});

router.get("/transactions", listTransactions);

module.exports = router;
