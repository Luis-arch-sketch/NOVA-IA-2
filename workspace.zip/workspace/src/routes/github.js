const express = require("express");
const { publicUser } = require("../middleware/auth");
const {
  isConfigured,
  authorizeUrl,
  exchangeCode,
  fetchGithubProfile,
  upsertGithubUser,
  importUserRepositories,
  randomState,
} = require("../services/github");

const router = express.Router();

router.get("/github", (req, res) => {
  if (!isConfigured()) {
    return res.redirect("/login?error=github_not_configured");
  }
  const state = randomState();
  req.session.githubOAuthState = state;
  req.session.save((err) => {
    if (err) return res.redirect("/login?error=github");
    res.redirect(authorizeUrl(req, state));
  });
});

router.get("/github/callback", async (req, res, next) => {
  try {
    if (!isConfigured()) {
      return res.redirect("/login?error=github_not_configured");
    }
    const { code, state } = req.query;
    if (!code || !state || state !== req.session.githubOAuthState) {
      return res.redirect("/login?error=github");
    }
    delete req.session.githubOAuthState;

    const token = await exchangeCode(req, String(code));
    const profile = await fetchGithubProfile(token);
    const { user } = await upsertGithubUser({
      profile,
      token,
      referralCode: req.cookies?.nova_ref || "",
    });

    await importUserRepositories(user.id).catch((err) => {
      console.error("GitHub import failed:", err.message);
    });

    req.session.userId = user.id;
    req.session.save((err) => {
      if (err) return next(err);
      res.redirect("/app?imported=github");
    });
  } catch (err) {
    console.error(err);
    res.redirect("/login?error=github");
  }
});

router.get("/github/status", (req, res) => {
  res.json({ configured: isConfigured() });
});

module.exports = { githubAuthRouter: router, publicUser };
