const express = require("express");
const { pool } = require("../db/pool");
const {
  importUserRepositories,
  listRepoFiles,
  readRepoFile,
  writeRepoFile,
  getUserToken,
} = require("../services/github");
const { sanitizeString } = require("../utils/validation");

const router = express.Router();

async function loadOwnedGithubProject(userId, projectId) {
  const { rows } = await pool.query(
    `SELECT id, name, description, source, github_repo_id, github_full_name, github_html_url, github_default_branch, created_at, updated_at
     FROM projects WHERE id = $1 AND user_id = $2`,
    [projectId, userId]
  );
  if (!rows.length) {
    const err = new Error("Projeto não encontrado.");
    err.status = 404;
    throw err;
  }
  if (rows[0].source !== "github" || !rows[0].github_full_name) {
    const err = new Error("Este projeto não está ligado a um repositório GitHub.");
    err.status = 400;
    throw err;
  }
  return rows[0];
}

router.post("/import-github", async (req, res, next) => {
  try {
    const token = await getUserToken(req.user.id);
    if (!token?.github_access_token) {
      return res.status(400).json({ error: "Entre com o GitHub para carregar os repositórios." });
    }
    const result = await importUserRepositories(req.user.id);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.get("/:id/files", async (req, res, next) => {
  try {
    const project = await loadOwnedGithubProject(req.user.id, req.params.id);
    const tree = await listRepoFiles(req.user.id, project);
    res.json({ project, ...tree });
  } catch (err) {
    next(err);
  }
});

router.get("/:id/file", async (req, res, next) => {
  try {
    const path = sanitizeString(req.query.path || "", 400);
    if (!path) return res.status(400).json({ error: "Informe o arquivo." });
    const project = await loadOwnedGithubProject(req.user.id, req.params.id);
    const file = await readRepoFile(req.user.id, project, path);
    res.json({ project, file });
  } catch (err) {
    next(err);
  }
});

router.put("/:id/file", async (req, res, next) => {
  try {
    const path = sanitizeString(req.body.path || "", 400);
    const content = typeof req.body.content === "string" ? req.body.content : "";
    const message = sanitizeString(req.body.message || "", 200);
    if (!path) return res.status(400).json({ error: "Informe o arquivo." });
    if (content.length > 750000) {
      return res.status(400).json({ error: "Arquivo grande demais para salvar por aqui." });
    }
    const project = await loadOwnedGithubProject(req.user.id, req.params.id);
    const saved = await writeRepoFile(req.user.id, project, { path, content, message });
    res.json({ ok: true, saved });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
