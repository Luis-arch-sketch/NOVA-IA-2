const express = require("express");
const { pool } = require("../db/pool");
const { sanitizeString, isValidName } = require("../utils/validation");

const router = express.Router();

router.get("/", async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT
         (SELECT COUNT(*) FROM conversations WHERE user_id = $1) AS conversations,
         (SELECT COUNT(*) FROM projects WHERE user_id = $1) AS projects,
         (SELECT COUNT(*) FROM messages m
            JOIN conversations c ON c.id = m.conversation_id
            WHERE c.user_id = $1 AND m.role = 'user') AS messages
       FROM users WHERE id = $1`,
      [req.user.id]
    );

    res.json({
      user: req.user,
      stats: {
        conversations: Number(rows[0]?.conversations || 0),
        projects: Number(rows[0]?.projects || 0),
        messages: Number(rows[0]?.messages || 0),
      },
    });
  } catch (err) {
    next(err);
  }
});

router.patch("/", async (req, res, next) => {
  try {
    const name = sanitizeString(req.body.name, 80);
    if (!isValidName(name)) {
      return res.status(400).json({ error: "Informe um nome válido (2 a 80 caracteres)." });
    }
    const { rows } = await pool.query(
      `UPDATE users SET name = $1, updated_at = NOW()
       WHERE id = $2
        RETURNING id, name, email, credits, referral_code, created_at, updated_at`,
      [name, req.user.id]
    );
    res.json({
      user: {
        id: rows[0].id,
        name: rows[0].name,
        email: rows[0].email,
        credits: Number(rows[0].credits),
        referralCode: rows[0].referral_code || null,
        createdAt: rows[0].created_at,
        updatedAt: rows[0].updated_at,
      },
    });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
