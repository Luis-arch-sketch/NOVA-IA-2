const express = require("express");
const { pool } = require("../db/pool");
const { sanitizeString } = require("../utils/validation");
const {
  importUserRepositories,
  listRepoFiles,
  readRepoFile,
  writeRepoFile,
  getUserToken,
} = require("../services/github");

const router = express.Router();
const PROJECT_FIELDS =
  "id, name, description, source, github_repo_id, github_full_name, github_html_url, github_default_branch, created_at, updated_at";

async function loadOwnedGithubProject(userId, projectId) {
  const { rows } = await pool.query(
    `SELECT ${PROJECT_FIELDS} FROM projects WHERE id = $1 AND user_id = $2`,
    [projectId, userId]
  );
  if (!rows.length) {
    const err = new Error("Projeto não encontrado.");
    err.status = 404;
    throw err;
  }
  if (rows[0].source !== "github" || !rows[0].github_full_name) {
    const err = new Error("Este projeto não está ligado a um repositório GitHub.");
    err.status = 400;
    throw err;
  }
  return rows[0];
}

router.get("/", async (req, res, next) => {
  try {
    const token = await getUserToken(req.user.id);
    if (token?.github_access_token) {
      await importUserRepositories(req.user.id).catch(() => {});
    }
    const { rows } = await pool.query(
      `SELECT ${PROJECT_FIELDS}
       FROM projects
       WHERE user_id = $1
       ORDER BY CASE WHEN source = 'github' THEN 0 ELSE 1 END, updated_at DESC`,
      [req.user.id]
    );
    res.json({
      projects: rows,
      githubConnected: Boolean(token?.github_login),
      githubLogin: token?.github_login || null,
    });
  } catch (err) {
    next(err);
  }
});

router.post("/import-github", async (req, res, next) => {
  try {
    const token = await getUserToken(req.user.id);
    if (!token?.github_access_token) {
      return res.status(400).json({ error: "Entre com o GitHub para carregar os repositórios." });
    }
    const result = await importUserRepositories(req.user.id);
    res.json(result);
  } catch (err) {
    next(err);
  }
});

router.post("/", async (req, res, next) => {
  try {
    const name = sanitizeString(req.body.name, 80);
    const description = sanitizeString(req.body.description || "", 500);
    if (!name || name.length < 2) {
      return res.status(400).json({ error: "Informe um nome de projeto (mínimo 2 caracteres)." });
    }
    const { rows } = await pool.query(
      `INSERT INTO projects (user_id, name, description, source)
       VALUES ($1, $2, $3, 'local')
       RETURNING ${PROJECT_FIELDS}`,
      [req.user.id, name, description]
    );
    res.status(201).json({ project: rows[0] });
  } catch (err) {
    next(err);
  }
});

router.get("/:id", async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT ${PROJECT_FIELDS}
       FROM projects WHERE id = $1 AND user_id = $2`,
      [req.params.id, req.user.id]
    );
    if (!rows.length) {
      return res.status(404).json({ error: "Projeto não encontrado." });
    }

    const conversations = await pool.query(
      `SELECT id, title, created_at, updated_at
       FROM conversations
       WHERE user_id = $1 AND project_id = $2
       ORDER BY updated_at DESC`,
      [req.user.id, req.params.id]
    );

    res.json({ project: rows[0], conversations: conversations.rows });
  } catch (err) {
    next(err);
  }
});

router.patch("/:id", async (req, res, next) => {
  try {
    const name = sanitizeString(req.body.name, 80);
    const description = sanitizeString(req.body.description || "", 500);
    if (!name || name.length < 2) {
      return res.status(400).json({ error: "Informe um nome de projeto." });
    }
    const { rows } = await pool.query(
      `UPDATE projects SET name = $1, description = $2, updated_at = NOW()
       WHERE id = $3 AND user_id = $4
        RETURNING ${PROJECT_FIELDS}`,
      [name, description, req.params.id, req.user.id]
    );
    if (!rows.length) {
      return res.status(404).json({ error: "Projeto não encontrado." });
    }
    res.json({ project: rows[0] });
  } catch (err) {
    next(err);
  }
});

router.delete("/:id", async (req, res, next) => {
  try {
    const result = await pool.query(
      "DELETE FROM projects WHERE id = $1 AND user_id = $2",
      [req.params.id, req.user.id]
    );
    if (!result.rowCount) {
      return res.status(404).json({ error: "Projeto não encontrado." });
    }
    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

router.get("/:id/files", async (req, res, next) => {
  try {
    const project = await loadOwnedGithubProject(req.user.id, req.params.id);
    const tree = await listRepoFiles(req.user.id, project);
    res.json({ project, ...tree });
  } catch (err) {
    next(err);
  }
});

router.get("/:id/file", async (req, res, next) => {
  try {
    const path = sanitizeString(req.query.path || "", 400);
    if (!path) return res.status(400).json({ error: "Informe o arquivo." });
    const project = await loadOwnedGithubProject(req.user.id, req.params.id);
    const file = await readRepoFile(req.user.id, project, path);
    res.json({ project, file });
  } catch (err) {
    next(err);
  }
});

router.put("/:id/file", async (req, res, next) => {
  try {
    const path = sanitizeString(req.body.path || "", 400);
    const content = typeof req.body.content === "string" ? req.body.content : "";
    const message = sanitizeString(req.body.message || "", 200);
    if (!path) return res.status(400).json({ error: "Informe o arquivo." });
    if (content.length > 750000) {
      return res.status(400).json({ error: "Arquivo grande demais para salvar por aqui." });
    }
    const project = await loadOwnedGithubProject(req.user.id, req.params.id);
    const saved = await writeRepoFile(req.user.id, project, { path, content, message });
    res.json({ ok: true, saved });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
