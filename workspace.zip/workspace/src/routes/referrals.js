const express = require("express");
const { getReferralOverview } = require("../services/referrals");

const router = express.Router();

router.get("/", async (req, res, next) => {
  try {
    const overview = await getReferralOverview(req.user.id);
    res.json(overview);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
