const OpenAI = require("openai");

const SYSTEM_PROMPT =
  "Você é a NOVA AI, uma inteligência artificial avançada da plataforma NOVA AI. " +
  "Responda em português do Brasil, de forma clara, precisa e útil. " +
  "Seja profissional, objetiva e respeitosa. Não invente fatos. " +
  "Quando não souber, diga que não sabe.";

function createClient() {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    const err = new Error(
      "A API da IA não está configurada. Defina OPENAI_API_KEY no servidor."
    );
    err.status = 503;
    throw err;
  }

  const options = { apiKey };
  if (process.env.OPENAI_BASE_URL) {
    options.baseURL = process.env.OPENAI_BASE_URL;
  }
  return new OpenAI(options);
}

function getModel() {
  return process.env.OPENAI_MODEL || "gpt-4o-mini";
}

async function generateReply(messages, extraSystem = "") {
  const client = createClient();
  const model = getModel();

  const payload = [
    { role: "system", content: extraSystem ? `${SYSTEM_PROMPT}\n\n${extraSystem}` : SYSTEM_PROMPT },
    ...messages.map((m) => ({
      role: m.role,
      content: m.content,
    })),
  ];

  const completion = await client.chat.completions.create({
    model,
    messages: payload,
    temperature: 0.7,
    max_tokens: 2048,
  });

  const choice = completion.choices && completion.choices[0];
  const content = choice?.message?.content?.trim();

  if (!content) {
    const err = new Error("A IA não retornou uma resposta. Tente novamente.");
    err.status = 502;
    throw err;
  }

  const usage = completion.usage || {
    prompt_tokens: 0,
    completion_tokens: 0,
    total_tokens: 0,
  };

  return {
    content,
    usage: {
      prompt_tokens: usage.prompt_tokens || 0,
      completion_tokens: usage.completion_tokens || 0,
      total_tokens: usage.total_tokens || 0,
    },
    model: completion.model || model,
  };
}

module.exports = {
  generateReply,
  getModel,
  createClient,
};
