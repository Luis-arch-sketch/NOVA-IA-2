const { pool } = require("../db/pool");

const INITIAL_CREDITS = BigInt(process.env.INITIAL_CREDITS || "1000000000");
const COMMAND_CREDIT_COST = Number(process.env.COMMAND_CREDIT_COST || 175000);
const GRANT_INTERVAL_MS =
  Number(process.env.CREDIT_GRANT_INTERVAL_HOURS || 24) * 60 * 60 * 1000;

function calculateCreditCost(_usage) {
  return COMMAND_CREDIT_COST;
}

async function grantDailyCreditsIfNeeded(userId) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows } = await client.query(
      "SELECT credits, last_credit_grant_at FROM users WHERE id = $1 FOR UPDATE",
      [userId]
    );

    if (!rows[0]) {
      await client.query("ROLLBACK");
      throw Object.assign(new Error("Usuário não encontrado."), { status: 404 });
    }

    const current = BigInt(rows[0].credits);
    const lastGrant = rows[0].last_credit_grant_at
      ? new Date(rows[0].last_credit_grant_at).getTime()
      : 0;
    const now = Date.now();
    const intervalElapsed = now - lastGrant >= GRANT_INTERVAL_MS;

    if (current === 0n && intervalElapsed) {
      await client.query(
        `UPDATE users
         SET credits = $1, last_credit_grant_at = NOW(), updated_at = NOW()
         WHERE id = $2`,
        [INITIAL_CREDITS.toString(), userId]
      );
      await client.query(
        `INSERT INTO credit_transactions (user_id, amount, type, description)
         VALUES ($1, $2, 'grant', $3)`,
        [
          userId,
          INITIAL_CREDITS.toString(),
          "Créditos diários concedidos após saldo zero.",
        ]
      );
      await client.query("COMMIT");
      return Number(INITIAL_CREDITS);
    }

    await client.query("COMMIT");
    return Number(current);
  } catch (err) {
    try {
      await client.query("ROLLBACK");
    } catch {
      /* ignore */
    }
    throw err;
  } finally {
    client.release();
  }
}

async function getBalance(userId) {
  const { rows } = await pool.query("SELECT credits FROM users WHERE id = $1", [userId]);
  if (!rows[0]) {
    throw Object.assign(new Error("Usuário não encontrado."), { status: 404 });
  }
  return Number(rows[0].credits);
}

async function deductCredits({ userId, cost, description, conversationId }) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows } = await client.query(
      "SELECT credits FROM users WHERE id = $1 FOR UPDATE",
      [userId]
    );

    if (!rows[0]) {
      await client.query("ROLLBACK");
      throw Object.assign(new Error("Usuário não encontrado."), { status: 404 });
    }

    const current = BigInt(rows[0].credits);
    const amount = BigInt(cost);

    if (current < amount) {
      await client.query("ROLLBACK");
      const err = new Error(
        "Seus créditos acabaram. Aguarde o próximo ciclo para receber novos créditos."
      );
      err.status = 402;
      err.code = "INSUFFICIENT_CREDITS";
      throw err;
    }

    const next = current - amount;
    await client.query(
      "UPDATE users SET credits = $1, updated_at = NOW() WHERE id = $2",
      [next.toString(), userId]
    );
    await client.query(
      `INSERT INTO credit_transactions (user_id, amount, type, description, conversation_id)
       VALUES ($1, $2, 'usage', $3, $4)`,
      [userId, (-amount).toString(), description, conversationId || null]
    );
    await client.query("COMMIT");
    return Number(next);
  } catch (err) {
    try {
      await client.query("ROLLBACK");
    } catch {
      /* ignore */
    }
    throw err;
  } finally {
    client.release();
  }
}

async function assertHasCredits(userId) {
  const { rows } = await pool.query("SELECT credits FROM users WHERE id = $1", [userId]);
  if (!rows[0]) {
    throw Object.assign(new Error("Usuário não encontrado."), { status: 404 });
  }
  const current = BigInt(rows[0].credits);
  const needed = BigInt(COMMAND_CREDIT_COST);
  if (current < needed) {
    const err = new Error(
      "Seus créditos acabaram. Aguarde o próximo ciclo para receber novos créditos."
    );
    err.status = 402;
    err.code = "INSUFFICIENT_CREDITS";
    throw err;
  }
  return Number(current);
}

module.exports = {
  calculateCreditCost,
  grantDailyCreditsIfNeeded,
  getBalance,
  deductCredits,
  assertHasCredits,
  INITIAL_CREDITS,
  COMMAND_CREDIT_COST,
};
