const crypto = require("crypto");
const { pool } = require("../db/pool");
const { INITIAL_CREDITS } = require("./credits");
const {
  generateReferralCode,
  findReferrerByCode,
  applyReferralReward,
  sanitizeReferralCode,
} = require("./referrals");

const GITHUB_AUTHORIZE = "https://github.com/login/oauth/authorize";
const GITHUB_TOKEN = "https://github.com/login/oauth/access_token";
const GITHUB_API = "https://api.github.com";

function isConfigured() {
  return Boolean(process.env.GITHUB_CLIENT_ID && process.env.GITHUB_CLIENT_SECRET);
}

function callbackUrl(req) {
  if (process.env.GITHUB_CALLBACK_URL) return process.env.GITHUB_CALLBACK_URL;
  const proto = req.get("x-forwarded-proto") || req.protocol || "https";
  const host = req.get("x-forwarded-host") || req.get("host");
  return `${proto}://${host}/api/auth/github/callback`;
}

function authorizeUrl(req, state) {
  const params = new URLSearchParams({
    client_id: process.env.GITHUB_CLIENT_ID,
    redirect_uri: callbackUrl(req),
    scope: "read:user user:email repo",
    state,
    allow_signup: "true",
  });
  return `${GITHUB_AUTHORIZE}?${params.toString()}`;
}

async function githubJson(url, token, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: {
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
      "User-Agent": "NOVA-AI",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(options.headers || {}),
    },
  });
  const text = await res.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { message: text };
  }
  if (!res.ok) {
    const err = new Error(data.message || "Falha ao falar com o GitHub.");
    err.status = res.status === 401 ? 401 : 502;
    throw err;
  }
  return data;
}

async function exchangeCode(req, code) {
  const res = await fetch(GITHUB_TOKEN, {
    method: "POST",
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      client_id: process.env.GITHUB_CLIENT_ID,
      client_secret: process.env.GITHUB_CLIENT_SECRET,
      code,
      redirect_uri: callbackUrl(req),
    }),
  });
  const data = await res.json();
  if (!data.access_token) {
    const err = new Error("Não foi possível autenticar com o GitHub.");
    err.status = 401;
    throw err;
  }
  return data.access_token;
}

async function fetchGithubProfile(token) {
  const user = await githubJson(`${GITHUB_API}/user`, token);
  const emails = await githubJson(`${GITHUB_API}/user/emails`, token).catch(() => []);
  const primary =
    (emails || []).find((item) => item.primary && item.verified) ||
    (emails || []).find((item) => item.verified) ||
    emails[0];
  const email =
    (primary && primary.email) ||
    user.email ||
    `${user.id}+${user.login}@users.noreply.github.com`;
  return {
    githubId: String(user.id),
    login: user.login,
    name: user.name || user.login,
    email: String(email).toLowerCase(),
    avatar: user.avatar_url || "",
  };
}

async function createUniqueCode(client) {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const code = generateReferralCode();
    const exists = await client.query("SELECT id FROM users WHERE referral_code = $1", [code]);
    if (!exists.rows.length) return code;
  }
  throw new Error("Não foi possível gerar um código de indicação.");
}

async function upsertGithubUser({ profile, token, referralCode }) {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const byGithub = await client.query("SELECT * FROM users WHERE github_id = $1 FOR UPDATE", [
      profile.githubId,
    ]);
    let user = byGithub.rows[0];

    if (!user) {
      const byEmail = await client.query("SELECT * FROM users WHERE email = $1 FOR UPDATE", [
        profile.email,
      ]);
      user = byEmail.rows[0];
    }

    if (user) {
      await client.query(
        `UPDATE users
         SET github_id = $1,
             github_login = $2,
             github_access_token = $3,
             github_avatar_url = $4,
             name = COALESCE(NULLIF(name, ''), $5),
             updated_at = NOW()
         WHERE id = $6`,
        [profile.githubId, profile.login, token, profile.avatar, profile.name, user.id]
      );
      const refreshed = await client.query(
        "SELECT id, name, email, credits, referral_code, github_login, created_at, updated_at FROM users WHERE id = $1",
        [user.id]
      );
      await client.query("COMMIT");
      return { user: refreshed.rows[0], created: false };
    }

    let referrer = null;
    const incoming = sanitizeReferralCode(referralCode || "");
    if (incoming) referrer = await findReferrerByCode(incoming, client);
    const ownCode = await createUniqueCode(client);

    const inserted = await client.query(
      `INSERT INTO users
        (name, email, password_hash, credits, last_credit_grant_at, referral_code, referred_by_user_id,
         github_id, github_login, github_access_token, github_avatar_url)
       VALUES ($1, $2, NULL, $3, NOW(), $4, $5, $6, $7, $8, $9)
       RETURNING id, name, email, credits, referral_code, github_login, created_at, updated_at`,
      [
        profile.name,
        profile.email,
        INITIAL_CREDITS.toString(),
        ownCode,
        referrer ? referrer.id : null,
        profile.githubId,
        profile.login,
        token,
        profile.avatar,
      ]
    );
    user = inserted.rows[0];
    await client.query(
      `INSERT INTO credit_transactions (user_id, amount, type, description)
       VALUES ($1, $2, 'grant', $3)`,
      [user.id, INITIAL_CREDITS.toString(), "Créditos iniciais ao criar a conta com GitHub."]
    );
    if (referrer && referrer.id !== user.id) {
      await applyReferralReward({ client, referrerId: referrer.id, referredId: user.id });
    }
    await client.query("COMMIT");
    return { user, created: true };
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

async function getUserToken(userId) {
  const { rows } = await pool.query(
    "SELECT github_access_token, github_login FROM users WHERE id = $1",
    [userId]
  );
  return rows[0] || null;
}

async function importUserRepositories(userId) {
  const row = await getUserToken(userId);
  if (!row?.github_access_token) {
    const err = new Error("Conecte sua conta GitHub para carregar os repositórios.");
    err.status = 400;
    throw err;
  }

  const repos = await githubJson(
    `${GITHUB_API}/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator`,
    row.github_access_token
  );
  const list = Array.isArray(repos) ? repos.slice(0, 80) : [];
  const imported = [];

  for (const repo of list) {
    const description = String(repo.description || repo.full_name || "").slice(0, 500);
    const name = String(repo.name || repo.full_name).slice(0, 80);
    const { rows } = await pool.query(
      `INSERT INTO projects
         (user_id, name, description, source, github_repo_id, github_full_name, github_html_url, github_default_branch)
       VALUES ($1, $2, $3, 'github', $4, $5, $6, $7)
       ON CONFLICT (user_id, github_repo_id)
       DO UPDATE SET
         name = EXCLUDED.name,
         description = EXCLUDED.description,
         github_full_name = EXCLUDED.github_full_name,
         github_html_url = EXCLUDED.github_html_url,
         github_default_branch = EXCLUDED.github_default_branch,
         updated_at = NOW()
       RETURNING id, name, description, source, github_repo_id, github_full_name, github_html_url, github_default_branch, created_at, updated_at`,
      [
        userId,
        name,
        description,
        String(repo.id),
        repo.full_name,
        repo.html_url,
        repo.default_branch || "main",
      ]
    );
    imported.push(rows[0]);
  }

  return { count: imported.length, projects: imported };
}

function encodePath(filePath) {
  return String(filePath)
    .split("/")
    .filter(Boolean)
    .map(encodeURIComponent)
    .join("/");
}

async function listRepoFiles(userId, project) {
  const row = await getUserToken(userId);
  if (!row?.github_access_token) {
    const err = new Error("GitHub não conectado.");
    err.status = 400;
    throw err;
  }
  const branch = project.github_default_branch || "main";
  const tree = await githubJson(
    `${GITHUB_API}/repos/${project.github_full_name}/git/trees/${encodeURIComponent(branch)}?recursive=1`,
    row.github_access_token
  );
  const files = (tree.tree || [])
    .filter((item) => item.type === "blob")
    .filter((item) => !item.path.includes("node_modules/") && !item.path.includes(".git/"))
    .slice(0, 400)
    .map((item) => ({
      path: item.path,
      size: item.size || 0,
      sha: item.sha,
    }));
  return { branch, truncated: Boolean(tree.truncated), files };
}

async function readRepoFile(userId, project, filePath) {
  const row = await getUserToken(userId);
  if (!row?.github_access_token) {
    const err = new Error("GitHub não conectado.");
    err.status = 400;
    throw err;
  }
  const data = await githubJson(
    `${GITHUB_API}/repos/${project.github_full_name}/contents/${encodePath(filePath)}?ref=${encodeURIComponent(
      project.github_default_branch || "main"
    )}`,
    row.github_access_token
  );
  if (data.encoding === "base64" && data.content) {
    const content = Buffer.from(data.content.replace(/\n/g, ""), "base64").toString("utf8");
    return {
      path: data.path,
      sha: data.sha,
      content,
      size: data.size,
      htmlUrl: data.html_url,
    };
  }
  const err = new Error("Este arquivo não pode ser aberto como texto.");
  err.status = 400;
  throw err;
}

async function writeRepoFile(userId, project, { path: filePath, content, message }) {
  const row = await getUserToken(userId);
  if (!row?.github_access_token) {
    const err = new Error("GitHub não conectado.");
    err.status = 400;
    throw err;
  }
  let sha;
  try {
    const current = await readRepoFile(userId, project, filePath);
    sha = current.sha;
  } catch {
    sha = undefined;
  }
  const body = {
    message: message || `Atualizar ${filePath} via NOVA AI`,
    content: Buffer.from(content, "utf8").toString("base64"),
    branch: project.github_default_branch || "main",
  };
  if (sha) body.sha = sha;
  const data = await githubJson(
    `${GITHUB_API}/repos/${project.github_full_name}/contents/${encodePath(filePath)}`,
    row.github_access_token,
    {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }
  );
  return {
    path: data.content?.path || filePath,
    sha: data.content?.sha,
    commit: data.commit?.sha,
    htmlUrl: data.content?.html_url,
  };
}

function randomState() {
  return crypto.randomBytes(16).toString("hex");
}

module.exports = {
  isConfigured,
  authorizeUrl,
  exchangeCode,
  fetchGithubProfile,
  upsertGithubUser,
  importUserRepositories,
  listRepoFiles,
  readRepoFile,
  writeRepoFile,
  getUserToken,
  randomState,
};
