const crypto = require("crypto");
const { pool } = require("../db/pool");

const REFERRAL_REWARD = BigInt(process.env.REFERRAL_REWARD_CREDITS || "3000000000");
const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function generateReferralCode(length = 8) {
  const bytes = crypto.randomBytes(length);
  let code = "";
  for (let i = 0; i < length; i += 1) {
    code += CODE_ALPHABET[bytes[i] % CODE_ALPHABET.length];
  }
  return code;
}

function sanitizeReferralCode(value) {
  if (typeof value !== "string") return "";
  return value.trim().toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 16);
}

async function ensureReferralCode(clientOrPool, userId) {
  const db = clientOrPool || pool;
  const current = await db.query(
    "SELECT referral_code FROM users WHERE id = $1",
    [userId]
  );
  if (current.rows[0]?.referral_code) {
    return current.rows[0].referral_code;
  }

  for (let attempt = 0; attempt < 8; attempt += 1) {
    const code = generateReferralCode();
    try {
      const updated = await db.query(
        `UPDATE users SET referral_code = $1, updated_at = NOW()
         WHERE id = $2 AND referral_code IS NULL
         RETURNING referral_code`,
        [code, userId]
      );
      if (updated.rows[0]?.referral_code) {
        return updated.rows[0].referral_code;
      }
      const again = await db.query(
        "SELECT referral_code FROM users WHERE id = $1",
        [userId]
      );
      if (again.rows[0]?.referral_code) {
        return again.rows[0].referral_code;
      }
    } catch (err) {
      if (err.code !== "23505") throw err;
    }
  }

  throw new Error("Não foi possível gerar um código de indicação.");
}

async function findReferrerByCode(code, client) {
  const clean = sanitizeReferralCode(code);
  if (!clean || clean.length < 4) return null;
  const db = client || pool;
  const { rows } = await db.query(
    "SELECT id, name, referral_code FROM users WHERE referral_code = $1",
    [clean]
  );
  return rows[0] || null;
}

async function applyReferralReward({ client, referrerId, referredId }) {
  if (!referrerId || referrerId === referredId) return null;

  const already = await client.query(
    "SELECT id FROM referrals WHERE referred_id = $1",
    [referredId]
  );
  if (already.rows.length) return null;

  const locked = await client.query(
    "SELECT id, credits FROM users WHERE id = $1 FOR UPDATE",
    [referrerId]
  );
  if (!locked.rows.length) return null;

  const next = BigInt(locked.rows[0].credits) + REFERRAL_REWARD;
  await client.query(
    "UPDATE users SET credits = $1, updated_at = NOW() WHERE id = $2",
    [next.toString(), referrerId]
  );
  await client.query(
    `INSERT INTO referrals (referrer_id, referred_id, reward_credits)
     VALUES ($1, $2, $3)`,
    [referrerId, referredId, REFERRAL_REWARD.toString()]
  );
  await client.query(
    `INSERT INTO credit_transactions (user_id, amount, type, description)
     VALUES ($1, $2, 'referral', $3)`,
    [
      referrerId,
      REFERRAL_REWARD.toString(),
      "Recompensa por indicação: um novo usuário criou conta com o seu link.",
    ]
  );
  return Number(REFERRAL_REWARD);
}

async function getReferralOverview(userId) {
  const code = await ensureReferralCode(pool, userId);
  const stats = await pool.query(
    `SELECT
       COUNT(*)::int AS invite_count,
       COALESCE(SUM(reward_credits), 0) AS total_earned
     FROM referrals
     WHERE referrer_id = $1`,
    [userId]
  );
  const list = await pool.query(
    `SELECT r.id, r.reward_credits, r.created_at, u.name
     FROM referrals r
     JOIN users u ON u.id = r.referred_id
     WHERE r.referrer_id = $1
     ORDER BY r.created_at DESC
     LIMIT 50`,
    [userId]
  );

  return {
    code,
    reward: Number(REFERRAL_REWARD),
    inviteCount: stats.rows[0].invite_count,
    totalEarned: Number(stats.rows[0].total_earned),
    invitations: list.rows.map((row) => ({
      id: row.id,
      name: row.name,
      rewardCredits: Number(row.reward_credits),
      createdAt: row.created_at,
    })),
  };
}

async function backfillReferralCodes() {
  const { rows } = await pool.query(
    "SELECT id FROM users WHERE referral_code IS NULL"
  );
  for (const row of rows) {
    await ensureReferralCode(pool, row.id);
  }
}

module.exports = {
  REFERRAL_REWARD,
  generateReferralCode,
  sanitizeReferralCode,
  ensureReferralCode,
  findReferrerByCode,
  applyReferralReward,
  getReferralOverview,
  backfillReferralCodes,
};
