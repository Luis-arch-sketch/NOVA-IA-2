const { calculateCreditCost } = require("../services/credits");

module.exports = { calculateCreditCost };
